@echo off
cd /d "%~dp0"
start "DRIFT//LIST local server" cmd /k "python -m http.server 8080"
timeout /t 2 /nobreak >nul
start "" http://localhost:8080
